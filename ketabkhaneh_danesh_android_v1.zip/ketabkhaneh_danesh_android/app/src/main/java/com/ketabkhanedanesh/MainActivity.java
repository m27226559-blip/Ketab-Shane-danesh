package com.ketabkhanedanesh;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    EditText search;
    TextView title;
    final int NAVY=Color.rgb(7,26,54), CARD=Color.rgb(16,43,80), BLUE=Color.rgb(21,151,255),
              GOLD=Color.rgb(255,181,46), WHITE=Color.WHITE, MUTED=Color.rgb(175,193,216),
              GREEN=Color.rgb(49,196,122);
    final ArrayList<Book> books = new ArrayList<>();
    String selectedCategory = "همه";

    static class Book {
        String name, author, category, text;
        Book(String n,String a,String c,String t){name=n;author=a;category=c;text=t;}
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(NAVY);
        seedBooks();
        buildHome();
    }

    void seedBooks(){
        books.add(new Book("فیزیک عمومی","مجله علوم پایه","علوم و فناوری",
                "فیزیک دانشی است که پدیده‌های طبیعت را بررسی می‌کند.\\n\\nفصل اول: اندازه‌گیری\\nاندازه‌گیری پایه بسیاری از آزمایش‌های علمی است. هر کمیت با عدد و واحد بیان می‌شود.\\n\\nفصل دوم: حرکت\\nحرکت تغییر مکان جسم نسبت به زمان است. سرعت، شتاب و نیرو از مفاهیم مهم این بخش‌اند."));
        books.add(new Book("ریاضیات پایه","محمد علی افشار","مضامین",
                "ریاضیات زبان الگوها و روابط است.\\n\\nدرس اول: اعداد\\nعددها برای شمارش و اندازه‌گیری به کار می‌روند.\\n\\nدرس دوم: هندسه\\nهندسه به بررسی شکل‌ها، اندازه‌ها و موقعیت آن‌ها می‌پردازد."));
        books.add(new Book("شاهنامه فردوسی","ابوالقاسم فردوسی","ادبیات",
                "شاهنامه از آثار بزرگ ادب فارسی است. این کتاب مجموعه‌ای از داستان‌های حماسی، تاریخی و اسطوره‌ای ایران است.\\n\\nاین نسخه آموزشی برای مطالعه و آشنایی با ادبیات فارسی تنظیم شده است."));
        books.add(new Book("تفکر و خلاقیت","دکتر پژوهش","مضامین",
                "خلاقیت یعنی توانایی دیدن راه‌های تازه برای حل مسئله.\\n\\nتمرین: یک مسئله روزمره انتخاب کنید و سه راه متفاوت برای حل آن بنویسید."));
        books.add(new Book("زبان انگلیسی مقدماتی","گروه آموزش","زبان‌های خارجی",
                "Lesson 1: Greetings\\nHello یعنی سلام. Good morning یعنی صبح بخیر.\\n\\nLesson 2: Simple sentences\\nI am a student. یعنی من یک دانش‌آموز هستم."));
    }

    TextView tv(String s,int sp, int color, boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.DEFAULT, bold?Typeface.BOLD:Typeface.NORMAL);
        t.setPadding(14,8,14,8);
        return t;
    }
    GradientDrawable bg(int color,float r){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(r); return g;
    }
    LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    LinearLayout col(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }

    void base(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(NAVY);
        setContentView(root);
        LinearLayout header=row(); header.setPadding(18,14,18,8);
        title=tv("کتابخانه دانش",24,WHITE,true); header.addView(title,new LinearLayout.LayoutParams(0,64,1));
        TextView profile=tv("👤",24,WHITE,false); profile.setGravity(Gravity.CENTER);
        header.addView(profile,new LinearLayout.LayoutParams(64,64));
        root.addView(header);
        content=col(); content.setPadding(14,4,14,10);
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=row(); nav.setPadding(8,6,8,6); nav.setBackgroundColor(Color.rgb(5,20,42));
        String[] ns={"خانه","کتاب‌ها","دانلودها","علاقه‌مندی‌ها","بیشتر"};
        for(String n:ns){ TextView x=tv(n,12, n.equals("خانه")?BLUE:MUTED,true); x.setGravity(Gravity.CENTER);
            nav.addView(x,new LinearLayout.LayoutParams(0,60,1));
            if(n.equals("کتاب‌ها")) x.setOnClickListener(v->showBooks());
            else if(n.equals("خانه")) x.setOnClickListener(v->buildHome());
        }
        root.addView(nav);
    }

    void buildHome(){
        base();
        TextView welcome=tv("دانش، یک قدم به سوی آینده است.",16,MUTED,false); content.addView(welcome);
        search=new EditText(this); search.setHint("جستجوی کتاب، نویسنده یا موضوع...");
        search.setHintTextColor(MUTED); search.setTextColor(WHITE); search.setSingleLine();
        search.setBackground(bg(CARD,40)); search.setPadding(22,0,22,0);
        content.addView(search,new LinearLayout.LayoutParams(-1,56));
        search.setOnEditorActionListener((v,a,e)->{filterBooks(search.getText().toString()); return true;});

        TextView banner=tv("📚  به دنیای کتاب‌های رایگان خوش آمدید!\nهر کتاب، یک قدم به سوی آینده بهتر.",18,WHITE,true);
        banner.setPadding(22,20,22,20); banner.setBackground(bg(Color.rgb(8,53,103),28));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,130); bp.setMargins(0,14,0,14); content.addView(banner,bp);

        TextView cats=tv("دسته‌بندی‌ها",19,WHITE,true); content.addView(cats);
        LinearLayout cr=row(); String[] cs={"همه","مضامین","ادبیات","علوم و فناوری","زبان‌های خارجی"};
        for(String c:cs){ TextView x=tv(c,12,WHITE,true); x.setGravity(Gravity.CENTER); x.setBackground(bg(CARD,24));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,62,1); p.setMargins(3,3,3,10); cr.addView(x,p);
            x.setOnClickListener(v->{selectedCategory=c; showBooks();});
        } content.addView(cr);

        TextView rec=tv("کتاب‌های پیشنهادی",20,WHITE,true); content.addView(rec);
        for(Book b:books) if(selectedCategory.equals("همه")||b.category.equals(selectedCategory)) addBookCard(b);
        TextView more=tv("مشاهده همه کتاب‌ها  ←",15,BLUE,true); more.setOnClickListener(v->showBooks()); content.addView(more);
    }

    void addBookCard(Book b){
        LinearLayout card=col(); card.setPadding(12,10,12,10); card.setBackground(bg(CARD,22));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,112); cp.setMargins(0,6,0,8);
        TextView n=tv("📘  "+b.name,17,WHITE,true); card.addView(n);
        TextView a=tv(b.author+"  •  "+b.category,12,MUTED,false); card.addView(a);
        TextView open=tv("رایگان  •  مطالعه",12,GREEN,true); open.setGravity(Gravity.RIGHT);
        card.addView(open);
        card.setTag((b.name+" "+b.author+" "+b.category)); card.setOnClickListener(v->openBook(b));
        content.addView(card,cp);
    }

    void showBooks(){
        base();
        TextView h=tv("همه کتاب‌ها",24,WHITE,true); content.addView(h);
        EditText q=new EditText(this); q.setHint("جستجو..."); q.setHintTextColor(MUTED); q.setTextColor(WHITE); q.setBackground(bg(CARD,35));
        q.setPadding(20,0,20,0); content.addView(q,new LinearLayout.LayoutParams(-1,56));
        for(Book b:books) addBookCard(b);
        q.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){filterBooksInView(s.toString());}
            public void afterTextChanged(android.text.Editable e){}
        });
    }

    void filterBooks(String q){ showBooks(); }
    void filterBooksInView(String q){
        String z=q.toLowerCase(Locale.ROOT);
        for(int i=0;i<content.getChildCount();i++){
            View v=content.getChildAt(i);
            if(v instanceof LinearLayout && v.getTag()!=null) v.setVisibility(View.VISIBLE);
        }
        // Simple refresh for reliability.
        if(q.trim().isEmpty()) return;
        for(int i=content.getChildCount()-1;i>=0;i--){
            View v=content.getChildAt(i);
            Object tag=v.getTag();
            if(tag instanceof String && !((String)tag).toLowerCase(Locale.ROOT).contains(z)) v.setVisibility(View.GONE);
        }
    }

    void openBook(Book b){
        base();
        TextView h=tv(b.name,24,WHITE,true); content.addView(h);
        TextView a=tv("نویسنده: "+b.author+"  •  "+b.category,13,MUTED,false); content.addView(a);
        TextView body=tv(b.text,17,WHITE,false); body.setGravity(Gravity.RIGHT|Gravity.TOP); body.setPadding(8,18,8,18);
        content.addView(body,new LinearLayout.LayoutParams(-1,-2));
        Button fav=new Button(this); fav.setText("☆ افزودن به علاقه‌مندی‌ها"); fav.setTextColor(WHITE); fav.setBackground(bg(BLUE,30));
        content.addView(fav,new LinearLayout.LayoutParams(-1,56));
    }
}